/* model.h
 */

#ifndef MODEL_H
#define MODEL_H

long int makep1 (void);
long int makep2 (void);
long int makep3 (void);
long int makep4 (void);
long int makep5 (void);
long int makep6 (void);
long int makep7 (void);

long int makef1 (void);
long int makef2 (void);
long int makef3 (void);

long int makeh1 (void);

#endif MODEL_H
