/* mk_prim.h
 */

#ifndef MK_PRIM_H
#define MK_PRIM_H

long int box (float x1, float x2, float x3, float x4, float y1, float y2, 
	      float y3, float y4, float z1, float z2, int c);

long int cil(float r1, float r2, float x2, float y2, float l, int c);

#endif MK_PRIM_H
