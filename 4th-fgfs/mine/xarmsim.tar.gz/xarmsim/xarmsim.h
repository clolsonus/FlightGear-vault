// xarmsim.h
//
// This file contains many constant definitions for xarmsim
//
// $Id: graph_main.c,v 1.19 1994/03/15 03:43:02 curt Exp $
// (Log is kept at end of this file)
//


// Window dimensions
#define X_SIZE 600
#define Y_SIZE 600

typedef double point[2];           /* array of length 2 */


//
// $Log: graph_main.c,v $
//
